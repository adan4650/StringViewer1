using System.Windows;

namespace StringViewer1
{
    public partial class App : Application
    {
    }
}